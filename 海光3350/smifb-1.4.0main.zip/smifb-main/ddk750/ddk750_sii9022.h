int sii9022xInitChip(void);
int sii9022xSetMode(int);
unsigned char sii9022xIsConnected(void);
int ddk750_GetDDC_9022Access(void);
int ddk750_Release9022DDC(void);
void ddk750_DoEdidRead(void);

