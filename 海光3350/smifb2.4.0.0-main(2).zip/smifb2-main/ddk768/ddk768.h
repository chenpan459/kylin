#ifndef DDK768_H__
#define DDK768_H__

#include "ddk768_reg.h"
#include "ddk768_help.h"


#include "ddk768_mode.h"
#include "ddk768_chip.h"
#include "ddk768_power.h"
#include "ddk768_display.h"
#include "ddk768_2d.h"
#endif
